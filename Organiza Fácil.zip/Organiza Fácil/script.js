let tarefas = [];

function adicionarTarefa() {
    const nome = document.getElementById("nome").value;
    const descricao = document.getElementById("descricao").value;

    if (nome === "") return;

    tarefas.push({
        nome: nome,
        descricao: descricao,
        concluida: false
    });

    ordenarTarefas();
    renderizar();
}

function ordenarTarefas() {
    tarefas.sort((a, b) => a.nome.localeCompare(b.nome));
}

function renderizar() {
    const lista = document.getElementById("lista");
    lista.innerHTML = "";

    tarefas.forEach((tarefa, index) => {
        const li = document.createElement("li");

        if (tarefa.concluida) {
            li.classList.add("concluida");
        }

        const botaoConcluir = document.createElement("button");
        botaoConcluir.innerText = "✔";
        botaoConcluir.onclick = () => toggleConcluida(index);

        const botaoExcluir = document.createElement("button");
        botaoExcluir.innerText = "❌";
        botaoExcluir.onclick = () => excluirTarefa(index);

        li.innerHTML = `<strong>${tarefa.nome}</strong><br>${tarefa.descricao}<br>`;
        li.appendChild(botaoConcluir);
        li.appendChild(botaoExcluir);

        lista.appendChild(li);
    });
}

function toggleConcluida(index) {
    tarefas[index].concluida = !tarefas[index].concluida;
    renderizar();
}

function excluirTarefa(index) {
    tarefas.splice(index, 1);
    renderizar();
}